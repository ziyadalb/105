from pathlib import Path
import json,csv,shutil,zipfile,hashlib,re
import pymupdf
from bs4 import BeautifulSoup
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parent;OUT=Path('/workspace/output/riyad111_ch4_51_v2');QA=ROOT/'qa'
meta=json.loads((ROOT/'metadata.json').read_text());records=meta['questions']
study=pymupdf.open(OUT/'study.pdf');solutions=pymupdf.open(OUT/'solutions.pdf')
main_texts=[p.get_text() for p in study];solution_texts=[p.get_text() for p in solutions]
mainhtml=BeautifulSoup((OUT/'study.html').read_text(),'html.parser')
heads=mainhtml.select('.question-head[data-qid]')
assert len(heads)==33 and len({h['data-qid'] for h in heads})==33
assert len(mainhtml.select('[data-stage="guided"]'))==9
assert len(mainhtml.select('[data-stage="independent"]'))==17
assert len(mainhtml.select('.sheet.example'))==7
assert len(study)==31
for q in records:
    q['study_page']=next(i+1 for i,t in enumerate(main_texts) if q['id'] in t)
    if q['stage']=='worked':q['solution_page']=q['study_page']
    else:q['solution_page']=len(study)+next(i+1 for i,t in enumerate(solution_texts) if q['id'] in t)
    q['solution_in_example']=q['stage']=='worked'

book=pymupdf.open();book.insert_pdf(study);book.insert_pdf(solutions)
total=len(book)
fontdir=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/share/fonts/truetype')
archive=pymupdf.Archive(str(fontdir))
linkcss='@font-face{font-family:LinkArabic;src:url(Amiri-Regular.ttf)}body{font-family:LinkArabic;font-size:11px;line-height:1.2;margin:0;text-align:right;color:#007d80}'
for i,page in enumerate(book):
    # Unify numbering across the main part and appendix without changing content.
    page.add_redact_annot(pymupdf.Rect(0,801,page.rect.width,page.rect.height),fill=(1,1,1))
    page.apply_redactions(images=0,graphics=0)
    page.draw_line(pymupdf.Point(51,800),pymupdf.Point(544,800),color=(.83,.88,.9),width=.5)
    page.insert_text((51,816),f'{i+1} / {total}',fontname='helv',fontsize=8,color=(.32,.43,.49))
    page.insert_htmlbox(pymupdf.Rect(370,803,544,828),'<div dir="rtl">رياض ١١١ · الرابع ودرس التجزئة 5.1</div>',css=linkcss,archive=archive)

link_count=0
for q in records:
    if q['stage']=='worked':continue
    mainpage=book[q['study_page']-1];solpage=book[q['solution_page']-1]
    mr=mainpage.search_for(q['id'])[0];sr=solpage.search_for(q['id'])[0]
    rect=pymupdf.Rect(425,mr.y0-1,544,mr.y0+14)
    label='<div dir="rtl">الحل · صفحة <span dir="ltr">'+str(q['solution_page'])+'</span></div>'
    mainpage.insert_htmlbox(rect,label,css=linkcss,archive=archive)
    mainpage.insert_link({'kind':pymupdf.LINK_GOTO,'from':rect,'page':q['solution_page']-1,'to':pymupdf.Point(0,max(0,sr.y0-35))})
    back=pymupdf.Rect(425,sr.y0,544,sr.y0+15)
    solpage.insert_htmlbox(back,'<div dir="rtl">ارجع للسؤال · صفحة <span dir="ltr">'+str(q['study_page'])+'</span></div>',css=linkcss,archive=archive)
    solpage.insert_link({'kind':pymupdf.LINK_GOTO,'from':back,'page':q['study_page']-1,'to':pymupdf.Point(0,max(0,mr.y0-35))})
    link_count+=2

toc=[[1,'الشرح والتدريب',1]]
for title,number in meta['section_starts'].items():toc.append([2,title,number])
toc.append([1,'الحلول والتفسير',len(study)+1])
for q in records:
    if q['stage']!='worked':toc.append([2,q['id'],q['solution_page']])
book.set_toc(toc)
book.set_metadata({'title':'رياض ١١١ — من السؤال إلى الحل','author':'مذكرة الميدتيرم المختارة','subject':'الرابع ضمن التحديد ودرس التجزئة 5.1؛ الشرح والتدريب والحلول في ملف واحد','keywords':'رياض111، ميدتيرم، قوالب، التجزئة'})
book.save(OUT/'riyad111_complete.pdf',garbage=4,deflate=True)
final=pymupdf.open(OUT/'riyad111_complete.pdf')
assert len(final)==total
text='\n'.join(p.get_text() for p in final)
assert all(q['id'] in text for q in records)
assert 'الملحق المنفصل' not in '\n'.join(p.get_text() for p in final[:len(study)])
assert len([l for p in final for l in p.get_links() if l['kind']==pymupdf.LINK_GOTO])>=52
for i,p in enumerate(final):
    p.get_pixmap(matrix=pymupdf.Matrix(.65,.65),alpha=False).save(QA/f'final-{i+1:02}.png')
for start in range(0,len(final),12):
    canvas=Image.new('RGB',(1072,1200),'#e6edf0');draw=ImageDraw.Draw(canvas)
    for j in range(start,min(start+12,len(final))):
        im=Image.open(QA/f'final-{j+1:02}.png');im.thumbnail((252,365));col=(j-start)%4;row=(j-start)//4
        canvas.paste(im,(268*col+8,400*row+22));draw.text((268*col+10,400*row+5),str(j+1),fill='black')
    canvas.save(QA/f'final-contact-{start//12+1}.png')
for n in [4,10,14,16,24,33]:
    final[n-1].get_pixmap(matrix=pymupdf.Matrix(1.2,1.2),alpha=False).save(QA/f'detail-{n}.png')
with (OUT/'question_registry.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
(OUT/'question_registry.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
mathcheck=json.loads((ROOT/'math_verification.json').read_text())
layout=json.loads((QA/'layout_checks.json').read_text())
report={'version':'v2 — revised teaching and approved visual direction',
 'scope':'33 unique selected questions; chapter four within previous scope and section 5.1.',
 'total_pages':total,'study_pages':len(study),'appendix_pages':len(solutions),'examples':7,'guided':9,'independent':17,
 'new_question_solution_links':link_count,'all_questions_present':True,'all_exercise_solutions_present':True,
 'math':{k:v for k,v in mathcheck.items() if k!='results'},'layout':layout,
 'visual_review':'All pages rendered; full contact sheets and representative full-size pages reviewed.',
 'fonts':'Noto Sans Arabic, Amiri and DejaVu Math embedded; verified using pdffonts.',
 'pdf_text_search':'Arabic and question identifiers extracted and checked.',
 'tested_renderers':['Chromium','PyMuPDF'],'ipad_app':'not run',
 'learning_claim':'Design and scaffolding revised; no measured student memory/time improvement claimed.'}
(OUT/'quality_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'combined_pages':total,'study_pages':len(study),'appendix_pages':len(solutions),'navigation_links_added':link_count,'questions':len(records)},ensure_ascii=False))
