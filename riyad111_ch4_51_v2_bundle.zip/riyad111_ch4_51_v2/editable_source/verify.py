"""Check the 33 displayed solution endpoints using the isolated math runtime."""
from pathlib import Path
import json
import sympy as s
import mpmath as mp
from content import S

ROOT=Path(__file__).resolve().parent
ns={}
exec(Path('/workspace/output/riyad111/verify.py').read_text().split("out=Path('/workspace/riyad111_audit')")[0],ns)
x=ns['x'];data=ns['data'];mp.mp.dps=60
answers={qid:data[qid][1] for qid in S}
# Displayed log equivalents differ from inverse-hyperbolic source endpoints by
# constants on domain components. Define them independently as authored.
for qid,u,a,sign,k,external in [
('M451-2-2',s.sqrt(x),1,1,2,False),
('M452-2-7',x+3,2,1,1,False),('M461-2-2',x+3,5,-1,3,False),
('M462-2-2',x+1,3,1,1,False),('M452-2-4',x**3,5,1,s.Rational(1,3),True),
('M462-2-7',s.exp(3*x),1,1,s.Rational(1,3),True),
('M471-2-2',5**x,1,1,1/s.log(5),True),
('M472-3-2',s.log(s.Abs(x)),1,-1,1,False),
('M471-2-4',x-3,4,-1,1,True),('M472-3-4',x-2,s.sqrt(2),-1,1,True)]:
    a,k=s.sympify(a),s.sympify(k)
    answers[qid]=k/a*s.log(s.Abs(u/(a+s.sqrt(a*a+sign*u*u)))) if external else k*s.log(s.Abs(u+s.sqrt(u*u+sign*a*a)))
results=[]
for qid,F in answers.items():
    f,old,points,kind=data[qid]
    source,target=(f,F) if kind=='derivative' else (F,f)
    fn,tn=s.lambdify(x,source,'mpmath'),s.lambdify(x,target,'mpmath')
    errors=[]
    for p in points:
        z=mp.mpf(str(s.N(p,55)));numeric=mp.diff(fn,z);expected=tn(z)
        errors.append(float(abs(numeric-expected)/(1+abs(expected))))
    passed=max(errors)<1e-40
    if kind=='definite':passed=passed and s.simplify(F.subs(x,s.E)-F.subs(x,1)-(3*s.E**4+1)/16)==0
    results.append({'id':qid,'passed':bool(passed),'numeric_points':len(errors),'maximum_relative_error':max(errors)})
assert all(r['passed'] for r in results)
report={'scope':'33 unique retained chapter-four and 5.1 questions. Displayed equivalent logarithmic answers independently differentiated.',
        'questions':len(results),'numeric_points':sum(r['numeric_points'] for r in results),'definite_value_checked':True,'all_passed':True,'results':results}
(ROOT/'math_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='results'},ensure_ascii=False))
