"""Approved teaching revision and visual design, scoped to retained ch4 + 5.1."""
from pathlib import Path
import json,html,base64,sys
from latex2mathml.converter import convert
from content import S

ROOT=Path(__file__).resolve().parent
OUT=Path('/workspace/output/riyad111_ch4_51_v2');OUT.mkdir(exist_ok=True)
DATA=json.loads((ROOT/'input_registry.json').read_text()) if (ROOT/'input_registry.json').exists() else json.load(open('/workspace/output/riyad111_ch4_51/question_registry.json'))
Q={r['id']:r for r in DATA}
assert len(Q)==33 and set(Q)==set(S)
maths=[];pages=[]
def E(tex,cls=''):
    maths.append(tex)
    return '<div class="eq '+cls+'" dir="ltr">'+convert(tex)+'</div>'
def P(text,cls=''):return '<p class="'+cls+'">'+text+'</p>'
def H(text):return '<h3>'+text+'</h3>'
def note(text):return '<div class="attention">'+text+'</div>'
def rule(text):return '<div class="rule">'+P(text)+'</div>'
def answer(tex):return '<div class="answer"><div class="caption">النتيجة</div>'+E(tex)+'</div>'
def row(n,title,text='',tex=''):
    return '<div class="row"><span class="step-no">'+str(n)+'</span><div class="copy">'+H(title)+(P(text) if text else '')+(E(tex) if tex else '')+'</div></div>'
def source(qid):return '<div class="source" dir="ltr"><a href="'+Q[qid]['source']+'">'+qid+' · Original midterm</a></div>'
def question(qid,hero=False):
    return '<div class="question-head" data-qid="'+qid+'">'+source(qid)+'<div class="english" dir="ltr">'+('Find the derivative.' if qid.split('-')[1]=='1' else 'Evaluate the integral.')+'</div>'+E(Q[qid]['question'],'hero' if hero else '')+'</div>'
def domain(qid):return '<div class="domain">'+P('مجال العمل:','small')+E(Q[qid]['domain'])+'</div>'
def progress(active):return '<div class="progress">'+''.join('<span class="'+('on' if i==active else '')+'">'+t+'</span>' for i,t in enumerate(['تعرّف على الشكل','شاهد الحل','جرّب بنفسك']))+'</div>'
def add(title,body,group,kind='lesson',active=None):
    pages.append({'title':title,'body':body,'group':group,'kind':kind,'active':active});return len(pages)
def worked(qid,title,group,pre=''):
    steps=S[qid]['steps'];body=question(qid,True)+pre
    for i,(text,tex) in enumerate(steps[:-1],1):body+=row(i,text,'',tex)
    body+=P(steps[-1][0])+answer(steps[-1][1])+domain(qid)
    return add(title,body,group,'example',1)
def exercise(qid,level='guided',cue=None,space=96):
    body=question(qid)
    if cue:body+=P(cue)
    if level=='guided':
        letter='D' if qid.split('-')[1]=='1' else ('B' if qid in ['M452-2-4','M471-2-2','M472-3-2'] else 'C')
        labels={'D':['ما الدالة الخارجية؟','ما الداخل ومشتقته؟'], 'B':['ما الداخل المناسب؟','ما علاقة التفاضل؟'], 'C':['أي جزء أشتقه؟','أي جزء أكامله؟']}[letter]
        body+='<div class="blanks">'+''.join('<div class="blank">'+t+'</div>' for t in labels)+'</div>'
    else:body+=P('العلامة: ............... البداية: ...............','small')
    return '<div class="exercise" data-stage="'+level+'">'+body+f'<div class="writing" style="height:{space}px"></div></div>'

add('من السؤال<br>إلى الحل.',
    '<div class="scope">الرابع ضمن تحديدك · ثم التجزئة 5.1</div>'+P('اعرف علامته، ابدأ بخطوة واضحة، ثم أكمل القالب بيدك.','lead')+
    E(r'\int\frac{dx}{\sqrt{x^2+2x+10}}','hero')+
    '<div class="route"><div><b>١</b>'+P('افهم العلامة')+'</div><div><b>٢</b>'+P('شاهد الخطوة')+'</div><div><b>٣</b>'+P('جرّب بنفسك')+'</div></div>'+
    '<div class="cover-bottom">٣٣ سؤالًا مختلفًا من ميداتك المختارة<br>٧ أمثلة · ٩ تدريبات موجّهة · ١٧ سؤالًا مستقلًا</div>'+P('الحلول التفصيلية وإجابات الاسترجاع في آخر هذا الملف.','small'),'ابدأ هنا','cover')
toc_page=add('طريقك داخل المذكرة','TOC','ابدأ هنا')
add('ماذا يطلب منك السؤال؟',
    H('إذا طلب المشتقة')+P('تبحث عن معدل تغيّر الدالة. افصل حدود الجمع، ثم تتبّع طبقات كل حد.')+E(r'y=f(x)\quad\Longrightarrow\quad y\prime=\frac{dy}{dx}')+
    H('إذا طلب التكامل')+P('تبحث عن دالة إذا اشتققتها ترجع إلى المعطى. في غير المحدد تضيف ثابتًا؛ مشتقته صفر.')+E(r'\int f(x)\,dx=F(x)+C,\qquad F\prime(x)=f(x)')+
    H('مهارتان ستحتاجهما أثناء الحل')+P('الجذر قوة كسرية، والمقلوب قوة سالبة:')+E(r'\sqrt{x}=x^{1/2},\qquad \frac1{x^2}=x^{-2}')+
    P('في تكامل القوة: زد الأس واحدًا، ثم اقسم على الأس الجديد. الأس سالب واحد له لوغاريتم بدل هذه الصيغة.')+E(r'\int x^n dx=\frac{x^{n+1}}{n+1}+C\;(n\ne-1),\qquad\int\frac{dx}{x}=\ln|x|+C')+
    note('إذا تعثرت في أساس جبري، ستجده مذكّرًا به عند الخطوة التي تحتاجه فيها. لا يلزمك حفظ صفحة رموز قبل رؤية المثال.'),'أساسيات البداية')

# Numeric-first explanation; one relevant rule, not the whole table, comes first.
add('ابدأ بالدالة الكبيرة',
    question('M472-1-1',True)+P('المطلوب مشتقة. الدالة الكبيرة هي معكوس الجيب الزائدي، وما داخلها لوغاريتم. سنحتاج قاعدة واحدة الآن.')+
    E(r'(\sinh^{-1}u)\prime=\frac{u\prime}{\sqrt{1+u^2}}')+
    row(1,'سمِّ ما بداخلها','الاسم مؤقت؛ نعيد التعبير الأصلي في آخر الحل.',r'u=\ln|x+1|')+
    row(2,'اشتق الداخل','مشتقة لوغاريتم القيمة المطلقة: مشتقة ما داخله على ما داخله.',r'u\prime=\frac{1}{x+1}')+
    row(3,'ضع الداخل ومشتقته في مكانهما','مشتقة الداخل فوق، والداخل نفسه يتربع تحت الجذر.')+
    answer(r'y\prime=\frac1{(x+1)\sqrt{1+(\ln|x+1|)^2}}')+
    P('عبارة التذكّر: اشتق الدالة الكبيرة، واترك داخلها، ثم اضرب في مشتقة الداخل.','small')+domain('M472-1-1'),'الرابع · الاشتقاق','example',1)
add('جدول المباشرات: احفظ بالمقارنة',
    P('الاسم التالي هو الداخل؛ والشرطة تعني مشتقته. طبّق الجدول حدًا حدًا بعد فصل الجمع.')+E(r'u=u(x),\qquad u\prime=\frac{du}{dx}')+
    H('الجيب وجيب التمام يتبادلان')+E(r'(\sinh u)\prime=u\prime\cosh u,\qquad(\cosh u)\prime=u\prime\sinh u')+
    H('الظل وظل التمام ينتجان مربعًا')+E(r'(\tanh u)\prime=u\prime\operatorname{sech}^2u')+E(r'(\coth u)\prime=-u\prime\operatorname{csch}^2u')+
    H('القاطع وقاطع التمام: سالب، ثم الدالة وشريكتها')+E(r'(\operatorname{sech}u)\prime=-u\prime\operatorname{sech}u\tanh u')+E(r'(\operatorname{csch}u)\prime=-u\prime\operatorname{csch}u\coth u')+
    note('الجيب وجيب التمام والظل والقاطع الزائدية تقبل داخلًا حقيقيًا. ظل التمام وقاطع التمام يحتاجان داخلًا غير صفري.')+
    rule('غطِّ الصيغ: أي الدوال تعطي السالب؟ وأيها تعطي مربعًا؟ ثم راجع إجابتك من الصف المطابق.'),'الرابع · الاشتقاق',active=0)
add('جدول العكسيات: راقب المقام',
    P('هذه عكسيات الدوال. الأس السالب واحد على اسم الدالة ليس مقلوبها العددي. الاسم التالي يمثل الداخل ومشتقته:')+E(r'u=u(x),\qquad u\prime=\frac{du}{dx}')+
    E(r'(\sinh^{-1}u)\prime=\frac{u\prime}{\sqrt{1+u^2}},\qquad u\in\mathbb R')+
    E(r'(\cosh^{-1}u)\prime=\frac{u\prime}{\sqrt{u^2-1}},\qquad u>1')+
    E(r'(\tanh^{-1}u)\prime=\frac{u\prime}{1-u^2},\qquad |u|<1')+
    E(r'(\coth^{-1}u)\prime=\frac{u\prime}{1-u^2},\qquad |u|>1')+
    E(r'(\operatorname{sech}^{-1}u)\prime=-\frac{u\prime}{u\sqrt{1-u^2}},\quad0<u<1')+
    E(r'(\operatorname{csch}^{-1}u)\prime=-\frac{u\prime}{|u|\sqrt{1+u^2}},\quad u\ne0')+
    note('أول اثنتين لهما جذران مختلفان. الظل وظل التمام لهما الصيغة نفسها ومجالان مختلفان. آخر اثنتين سالبتان؛ القيمة المطلقة تظهر في الأخيرة.')+
    P('شروط الجدول للمشتقة. مجال السؤال كله هو تقاطع شروط حدوده.','small'),'الرابع · الاشتقاق',active=0)
worked('M451-1-1','افصل الحدين، ثم اشتق','الرابع · الاشتقاق')
add('كل طبقة لها مشتقة',
    P('هذا جزء من السؤال الذي ستكمله أسفل الصفحة. الدالة مرفوعة للقوة الثالثة، وداخلها مقلوب؛ إذن توجد ثلاث طبقات.')+
    E(r'\sinh^3(1/x)')+
    row(1,'اشتق القوة','تخرج الثلاثة وتقل القوة واحدًا.',r'3\sinh^2(1/x)')+
    row(2,'اضرب بمشتقة الدالة الزائدية','يتبدل الجيب الزائدي إلى جيب التمام الزائدي؛ الداخل يبقى كما هو.',r'\cosh(1/x)')+
    row(3,'اضرب بمشتقة المقلوب','هنا يأتي السالب الذي قد يضيع.',r'(1/x)\prime=-1/x^2')+
    note('في الحد الآخر من السؤال توجد طبقتان: عكسية ثم جذر. اكتب مشتقة كل طبقة قبل الاختصار.')+
    exercise('M452-1-2','guided',space=60),'الرابع · الاشتقاق','practice',2)
add('اختر الطبقات بنفسك',
    P('اكتب الخارجية، ثم الداخل ومشتقته. أكمل الحل بعد ذلك. التلميح والحل الكامل في الملحق.')+
    exercise('M462-1-1','guided',space=130)+exercise('M472-1-2','guided',space=130)+
    P('بعد الحل: هل وضعت القيمة المطلقة حيث تلزم؟ وهل حافظت على مشتقة الجذر؟','small'),'الرابع · الاشتقاق','practice',2)

add('نصّ الوسط، وانسخ الجذر',
    question('M462-2-2',True)+P('نلاحظ ثلاث علامات: البسط ثابت، ومعامل مربع المتغير واحد، والمقام هو الجذر وحده. لهذا السؤال اختصار مباشر.')+
    row(1,'خذ نصف معامل الوسط','معامل الحد الأوسط اثنان؛ نأخذ نصفه.',r'\frac22=\boxed{1}')+
    row(2,'اكتب المتغير ثم أضف العدد','هذا ما يأتي قبل الجذر داخل اللوغاريتم.',r'x+\boxed1')+
    row(3,'انسخ الجذر وأكمل','نضع المجموع داخل لوغاريتم القيمة المطلقة، ثم نضيف ثابت التكامل.')+
    answer(r'\ln\left|x+1+\sqrt{x^2+2x+10}\right|+C')+
    note('سبب الحركة: إكمال المربع يجعل الإزاحة واحدًا؛ الجذر الأصلي يبقى كما هو.')+
    E(r'x^2+2x+10=(x+1)^2+9')+domain('M462-2-2'),'الرابع · الجذور','example',1)
add('اختر شكل الجواب بعد التجهيز',
    P('سنسمّي الداخل باسم مؤقت. الثابت في القالب هو الجذر الموجب للثابت المربع، والمعامل يأتي من البسط والتفاضل:')+
    E(r'u,\qquad a>0,\qquad k')+
    H('بلا عامل خارجي: الداخل مع الجذر')+
    E(r'\int\frac{k\,du}{\sqrt{u^2\pm a^2}}=k\ln\left|u+\sqrt{u^2\pm a^2}\right|+C')+
    H('مع العامل الخارجي المطابق للداخل')+
    E(r'\int\frac{k\,du}{u\sqrt{a^2\pm u^2}}')+
    answer(r'\frac{k}{a}\ln\left|\frac{u}{a+\sqrt{a^2\pm u^2}}\right|+C')+
    rule('عبارة الثاني: الداخل فوق، الثابت والجذر تحت، واقسم على الثابت.')+
    note('اكتب التعويض والتفاضل وحوّل التكامل كله قبل الاختيار. قد يظهر العامل الخارجي أو يختفي أثناء التحويل.')+
    P('الجذر في المقام موجب، والداخل الخارجي غير صفري، وحجة اللوغاريتم غير صفرية. الإشارة تُنسخ في موضعها داخل كل شكل. تفسير الصيغ بالتفاضل في الملحق.','small'),'الرابع · الجذور',active=0)
add('كيف أكتشف التعويض المناسب؟',
    P('نريد أن يصبح الجذر: واحد زائد مربع شيء. في السؤال الأسّي من ميدتيرمك نلاحظ:')+
    E(r'e^{6x}=(e^{3x})^2')+
    row(1,'سمِّ الشيء الذي يتربع','لهذا اخترنا الأس الثالث، وليس اسمًا عشوائيًا.',r'u=e^{3x}')+
    row(2,'اشتق ثم استخرج التفاضل','مشتقة الأُسّي تعطي ثلاثة أمثال الداخل.',r'du=3u\,dx\quad\Longrightarrow\quad dx=\frac{du}{3u}')+
    row(3,'حوّل الكسر كله','لاحظ العامل الذي ظهر خارج الجذر.',r'\int\frac{dx}{\sqrt{1+e^{6x}}}=\frac13\int\frac{du}{u\sqrt{1+u^2}}')+
    H('قارن بسؤال اللوغاريتم')+P('هنا تفاضل الداخل يستهلك العامل الخارجي بدل أن يضيف عاملًا جديدًا:')+
    E(r'u=\ln|x|,\quad du=\frac{dx}{x},\quad\int\frac{dx}{x\sqrt{(\ln|x|)^2-1}}=\int\frac{du}{\sqrt{u^2-1}}')+
    note('القاعدة التي تتذكرها: أبحث عن الشكل الأسهل، أكتب تفاضله، ثم أنظر إلى التكامل الجديد. هذان تمهيدان لأسئلة ستعيد حلها بنفسك.'),'الرابع · الجذور',active=0)
worked('M471-2-4','العامل الخارجي يحدد الداخل','الرابع · الجذور')
add('جهّز، ثم املأ القالب',
    P('ابدأ بعلاقة التعويض والتفاضل؛ بعدها اختر جواب الجذر المناسب. اترك المعامل خارج الجواب كله.')+
    exercise('M452-2-4','guided',space=75)+exercise('M471-2-2','guided',space=75)+exercise('M472-3-2','guided',space=75),'الرابع · الجذور','practice',2)
add('ميّز قبل أن تحسب',
    P('هذه إعادة تدريب على أجزاء من أسئلتك، وليست أسئلة إضافية في العدد. اكتب البداية فقط دون إكمال التكامل.')+
    H('أ. الجذران: أي جذر أسميه؟')+E(r'\int\frac{dx}{\sqrt{x}\sqrt{1+x}}')+P('التعويض: ............... علاقة التفاضل: ...............')+'<div class="writing" style="height:55px"></div>'+
    H('ب. الجذر التربيعي المزاح: ما نصف الوسط؟')+E(r'\int\frac{3\,dx}{\sqrt{x^2+6x-16}}')+P('نصف الوسط: ............... معامل الجواب كله: ...............')+'<div class="writing" style="height:55px"></div>'+
    H('ج. قارن النتيجة بعد التحويل')+P('لماذا لا يكفي وجود عامل خارج الجذر في السؤال الأصلي لاختيار الجواب؟ اشرح باستخدام سؤال الأُسّي أو اللوغاريتم.')+'<div class="writing" style="height:85px"></div>'+
    note('قبل الانتقال: اكتب عبارة القالب، واذكر علامة واحدة تمنع استعماله. الإجابات في الملحق.'),'الرابع · الجذور','practice',2)

add('زد الأس، ثم املأ الجواب',
    question('M471-2-7',True)+P('قوة مضروبة في لوغاريتم. نستخدم الأس الجديد في ثلاثة أماكن: القوة، والمقام، والتصحيح داخل القوس.')+
    row(1,'زد الأس واحدًا','الأس الأصلي ثلاثة، فيصير أربعة.',r'3+1=\boxed4')+
    row(2,'اقسم القوة على الأس الجديد','اترك اللوغاريتم كما هو.',r'\frac{x^4}{4}\ln|2x|')+
    row(3,'اطرح مقلوب الأس الجديد داخل القوس','أضف ثابت التكامل في النهاية.')+
    answer(r'\frac{x^4}{4}\left(\ln|2x|-\frac14\right)+C')+
    note('لا تقسّم على اثنين بسبب وجوده داخل اللوغاريتم. مشتقته تختصر هذا المعامل:')+
    E(r'\frac{d}{dx}\ln|2x|=\frac2{2x}=\frac1x')+domain('M471-2-7'),'5.1 · التجزئة','example',1)
add('قالب اللوغاريتم: جرّبه بأس سالب',
    P('اسم الأس الأصلي، وثابت الداخل غير الصفري، ثم الأس الجديد:')+E(r'n,\qquad a\ne0,\qquad m=n+1\ne0')+
    E(r'\int x^n\ln|ax|dx=\frac{x^m}{m}\left(\ln|ax|-\frac1m\right)+C')+
    rule('زد الأس، اقسم عليه، واطرح مقلوبه من اللوغاريتم.')+
    note('الأس الأصلي سالب واحد يجعل الأس الجديد صفرًا؛ لا نستخدم الصيغة حينها. تفسير القالب واستثناؤه في الملحق.')+
    H('دورك: السالب لا يمنع الفكرة')+exercise('M461-2-5','guided',space=110)+
    P('بعد الحل: هل استخدمت الأس الجديد نفسه في كل خانة؟ هل تحوّل طرح مقلوب السالب إلى موجب؟','small'),'5.1 · التجزئة','practice',2)
worked('M452-2-2','اختر الجزء الذي يصبح أبسط','5.1 · التجزئة',
       P('سنشتق العامل الخطي لأنه يصبح ثابتًا، ونكامل جيب التمام بسهولة. هذا سبب اختيار خانات التجزئة في هذا السؤال.'))
add('التجزئة: أربعة أماكن ثابتة',
    P('تخيّل أن حاصل الضرب يتوزع بين جزأين. نشتق الجزء الذي يصبح أبسط، ونكامل الجزء الذي نعرف تكامله.')+
    E(r'\int u\,dv=uv-\int v\,du')+
    P('الأسماء الأربعة بالترتيب: الجزء الذي نشتقه، تفاضله، الجزء الذي نكامله، تكامله.')+E(r'u,\quad du,\quad dv,\quad v')+
    H('في العامل الخطي: الخطي مع الأول، ومعامله مع الثاني')+
    P('معامل العامل الخطي وثابته هما الحرفان الظاهران في القوس:')+E(r'ax+b')+
    E(r'\int(ax+b)\cos x\,dx=(ax+b)\sin x+a\cos x+C')+
    E(r'\int(ax+b)\sinh x\,dx=(ax+b)\cosh x-a\sinh x+C')+
    E(r'\int(ax+b)\cosh x\,dx=(ax+b)\sinh x-a\cosh x+C')+
    note('داخل الدوال هنا هو المتغير نفسه. في حالة جيب التمام، سالب التجزئة مع سالب التكامل الثاني يعطي موجبًا. في الحل التحريري اكتب خانات التجزئة والتكامل المتبقي.'),'5.1 · التجزئة',active=0)
worked('M451-2-5','إذا ظهرت العكسية وحدها','5.1 · التجزئة',
       P('العامل غير المكتوب هو الواحد. نكامل الواحد إلى المتغير، ونجعل العكسية الجزء الذي نشتقه.'))
add('التصحيح يحدد إشارة الجواب',
    P('بعد حاصل الضرب في التجزئة، نطرح تكاملًا أصغر. هذا هو «التصحيح». في أسئلتك له ثلاثة أشكال قصيرة.')+
    H('تحت الجذر: مربع المتغير ناقص واحد')+E(r'\int\frac{x}{\sqrt{x^2-1}}dx=\sqrt{x^2-1}+C')+
    H('تحت الجذر: واحد ناقص مربع المتغير')+E(r'\int\frac{x}{\sqrt{1-x^2}}dx=-\sqrt{1-x^2}+C')+
    H('المقام بلا جذر')+E(r'\int\frac{x}{1+x^2}dx=\frac12\ln(1+x^2)+C')+
    P('لإعادة بنائها: سمِّ ما تحت الجذر أو المقام داخلًا. مشتقته تعطي ضعفي المتغير، موجبًا أو سالبًا؛ منها يأتي النصف والإشارة.')+
    note('في التجزئة نطرح التصحيح. إذا كان التصحيح سالبًا يصبح هذا الجزء موجبًا. لا تحفظ إشارة واحدة لكل العكسيات.')+
    H('مشتقتا العكسيتين المثلثيتين اللازمتان')+E(r'(\sin^{-1}x)\prime=\frac1{\sqrt{1-x^2}},\;|x|<1')+E(r'(\tan^{-1}x)\prime=\frac1{1+x^2},\;x\in\mathbb R'),'5.1 · التجزئة',active=0)
add('املأ الخانات ثم أكمل التصحيح',
    P('قارن العامل أمام العكسية: إذا لم يظهر عامل فهو واحد. إذا ظهر المتغير فتكامله نصف المربع.')+
    exercise('M462-2-8','guided',space=125)+exercise('M472-3-1','guided',space=125)+
    note('غطِّ الحل السابق قبل المحاولة. إذا علقت في إشارة التصحيح، ارجع إلى مشتقة ما تحت الجذر، لا إلى تخمين الإشارة.'),'5.1 · التجزئة','practice',2)
add('استرجع قبل التدريب المختلط',
    P('أغلق صفحات القوانين. اكتب من ذاكرتك، ثم راجع إجابات الاسترجاع في الملحق.')+
    row(1,'الاشتقاق','اكتب قانون السلسلة. كم طبقة في الجيب الزائدي المكعب ذي الداخل المقلوب؟')+
    row(2,'جدولا المشتقات','أي صيغ المباشرات فيها سالب؟ وما الفرق بين مقامَي معكوس القاطع وقاطع التمام الزائديين؟')+
    row(3,'الجذور','اكتب شكلَي الجواب. متى تفحص العامل خارج الجذر: قبل تحويل التكامل أم بعده؟')+
    row(4,'اللوغاريتم','ما الأس الجديد؟ أين تضعه؟ ومتى لا تستخدم القالب؟')+
    row(5,'التجزئة','لماذا نشتق العامل الخطي؟ وما تكامل العامل في العكسية وحدها أو مع المتغير؟')+
    row(6,'المحدد','بعد إيجاد الدالة الأصلية، أي حد تطرح من الآخر؟ وهل تضيف ثابت التكامل؟')+
    '<div class="writing" style="height:150px"></div>','استرجاع قبل الحل','practice',2)

ind=['M451-1-2','M451-2-3','M451-2-2','M452-1-1','M461-2-4','M452-2-7','M461-1-1','M452-2-5','M472-3-4','M461-1-2','M471-2-5','M461-2-2','M462-1-2','M462-2-7','M462-2-3','M471-1-1','M471-1-2']
for start in range(0,len(ind),3):
    body=P('اكتب العلامة وأول سطر قبل الحساب. التلميح والبداية والحل الكامل في الملحق؛ افتح أقل مساعدة تحتاجها.')
    for qid in ind[start:start+3]:body+=exercise(qid,'independent',space=103)
    add('اختر الطريقة بنفسك',body,'التدريب المختلط','practice',2)
add('ورقة تذكّر: الرابع',
    H('المشتقة: كل طبقة لها مشتقة')+E(r'[F(u)]\prime=F\prime(u)u\prime')+
    P('افصل الجمع، واترك الداخل كما هو، ثم اضرب بمشتقته. إذا كان مركبًا فأكمل طبقاته.')+
    H('التربيعي: نصّ الوسط وانسخ الجذر')+P('معامل المربع واحد، والبسط ثابت، ولا عامل إضافي خارج الجذر. اسما معامل الوسط والثابت الأخير:')+E(r'b,\quad c')+
    E(r'\int\frac{k\,dx}{\sqrt{x^2+bx+c}}=k\ln\left|x+\frac b2+\sqrt{x^2+bx+c}\right|+C')+
    H('بعد التعويض: اختر من الشكل الجديد')+E(r'\int\frac{k\,du}{\sqrt{u^2\pm a^2}}=k\ln|u+\sqrt{u^2\pm a^2}|+C')+
    E(r'\int\frac{k\,du}{u\sqrt{a^2\pm u^2}}=\frac{k}{a}\ln\left|\frac{u}{a+\sqrt{a^2\pm u^2}}\right|+C')+
    note('ثابت القالب موجب، والجذر في المقام موجب، وكل المقامات وحجج اللوغاريتم معرفة. لا تسقط معامل التفاضل، وأعد المتغير الأصلي.'),'ورقتا التذكّر')
add('ورقة تذكّر: التجزئة',
    H('القانون الذي يعيد لك الطريق')+E(r'\int u\,dv=uv-\int v\,du')+
    P('اللوغاريتم والعكسية للجزء الذي نشتقه. العامل الخطي مع الدالة نجعله الجزء المشتق لأنه يصبح ثابتًا.')+
    H('القوة واللوغاريتم')+E(r'm=n+1\ne0,\qquad a\ne0')+
    E(r'\int x^n\ln|ax|dx=\frac{x^m}{m}\left(\ln|ax|-\frac1m\right)+C')+
    P('زد الأس، اقسم عليه، واطرح مقلوبه. لا تضف قسمة على ثابت داخل اللوغاريتم.')+
    H('العكسية')+P('كامل العامل العادي أولًا، ثم اضرب تكامله بالعكسية، واطرح التصحيح. احسب إشارته من التفاضل.')+
    H('التكامل المحدد')+E(r'\int_a^b f(x)dx=F(b)-F(a)')+
    note('قبل التسليم: مشتقة الداخل؟ النصف؟ السالب؟ ثابت التكامل في غير المحدد؟ المجال؟ بعد التصحيح أعد السؤال الذي أخطأت فيه دون النظر للحل.'),'ورقتا التذكّر')

# Contents and source-linked question positions are generated from actual pages.
starts={}
for i,p in enumerate(pages,1):starts.setdefault(p['group'],i)
pages[toc_page-1]['body']='<div class="contents">'+''.join('<a href="#p'+str(n)+'"><span>'+g+'</span><b>'+str(n)+'</b></a>' for g,n in starts.items())+'</div>'+H('كيف تستخدم الصفحة؟')+P('شاهد المثال، ثم غطِّ الخطوة التالية وحاول توقعها. بعدها املأ التدريب الموجّه، ثم اكتب البداية من ذاكرتك في المختلط.')+P('إذا أخطأت، حدّد أول موضع تعثّرت فيه: اختيار، قانون، مشتقة الداخل، جبر، أو إشارة. عالج هذه الخطوة ثم أعد السؤال بعد فاصل.')+note('الهدف هو استرجاع البداية ثم إكمال الحل. سهولة الحفظ والسرعة تُقاسان بمحاولتك، لا بعدد الصفحات.')

fonts=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/share/fonts/truetype')
def b64(path):return base64.b64encode(Path(path).read_bytes()).decode()
fontcss=''
for name,path,weight in [('Head','/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf',400),('Head','/usr/share/fonts/truetype/noto/NotoSansArabic-Bold.ttf',700),('Read',fonts/'Amiri-Regular.ttf',400),('Read',fonts/'Amiri-Bold.ttf',700),('StudyMath',fonts/'DejaVuMathTeXGyre.ttf',400)]:
    fontcss+=f'@font-face{{font-family:{name};src:url(data:font/ttf;base64,{b64(path)});font-weight:{weight}}}'
css=fontcss+'''
@page{size:A4;margin:0}*{box-sizing:border-box}body{margin:0;background:#e6edf0;color:#163347;font:21px/1.6 Read,serif}
.sheet{width:210mm;height:297mm;margin:16px auto;background:#fff;position:relative;padding:13mm 18mm 18mm;break-after:page}.sheet:last-child{break-after:auto}.content{width:100%}
.mast{font:11px Head;display:flex;justify-content:space-between;padding-bottom:8px;border-bottom:1px solid #c6d7dd;margin-bottom:17px;color:#506c7c}.brand{font-weight:700;color:#163347}
h1,h2,h3,.small,.caption,.scope,.progress,.step-no,.footer,.tag{font-family:Head,sans-serif}h1{font-size:32px;line-height:1.4;margin:0 0 15px;color:#102e44}h3{font-size:17px;line-height:1.6;margin:6px 0;color:#17394d}p{margin:7px 0 11px}.lead{font-size:25px;line-height:1.65}.small{font-size:12px;line-height:1.9;color:#506c7c}.caption{font-size:11px;color:#007d80}
.eq{direction:ltr;unicode-bidi:isolate;text-align:center;font-family:StudyMath;line-height:1.4;margin:11px 0 13px}math{font:20px StudyMath;direction:ltr}mtext{font-family:Read}.eq.hero{padding:15px 9px;background:#eef6f7;border-top:3px solid #007d80;margin:17px 0}.eq.hero math{font-size:25px}
.source{font:10px Arial;direction:ltr;text-align:left;margin:10px 0 3px;color:#506c7c}a{color:#246680;text-decoration:none}.english{font:12px Arial;direction:ltr;text-align:left;margin:3px 0 7px}
.progress{display:flex;gap:7px;margin-bottom:17px;font-size:11px}.progress span{flex:1;border-top:3px solid #d8e3e7;padding-top:6px;color:#68818d}.progress .on{color:#007d80;border-color:#007d80;font-weight:700}
.row{display:flex;gap:13px;padding:8px 0;border-bottom:1px solid #d9e3e7;break-inside:avoid}.step-no{font-size:20px;min-width:24px;line-height:1.7;color:#007d80}.copy{flex:1;min-width:0}.row p{margin:3px 0}.row .eq{margin:9px 0}
.rule{border-inline-start:4px solid #007d80;background:#eef6f7;padding:6px 16px;margin:16px 0}.rule p{margin:5px 0}.attention{border-top:1px solid #dfc27d;padding-top:9px;margin:16px 0 9px;font-size:19px;line-height:1.6}.answer{border-top:3px solid #007d80;background:#eef6f7;padding:8px;margin:16px 0}.answer .eq{margin:9px 0}.answer math{font-size:22px}.domain{margin-top:11px}.domain .eq{margin:5px 0}.domain math{font-size:17px}
.example .row{padding:6px 0}.example .eq.hero{padding:12px 9px;margin:15px 0}.example .answer{margin:12px 0}
.blanks{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin:10px 0}.blank{font-size:17px;border-bottom:1px solid #a5bbc6;min-height:34px}.writing{border-bottom:1px solid #d3e0e6;margin:12px 0 20px}.exercise{break-inside:avoid;margin:13px 0 24px}.exercise .eq{margin:9px 0}.practice h1{color:#355e3d}.practice .progress .on{color:#466c3b;border-color:#466c3b}
.footer{position:absolute;bottom:8mm;inset-inline:18mm;display:flex;justify-content:space-between;font-size:10px;color:#607c8b;border-top:1px solid #d9e3e7;padding-top:7px}.contents a{display:flex;justify-content:space-between;font:15px/1.8 Head;border-bottom:1px solid #d9e3e7;padding:9px 0}.contents{margin:12px 0 20px}
.cover{padding-top:20mm}.cover .mast{margin-bottom:38px}.cover h1{font-size:54px;line-height:1.5;margin-bottom:20px}.scope{font-size:15px;color:#007d80;margin:16px 0 25px}.route{display:flex;justify-content:space-between;border-top:1px solid #c6d7dd;margin-top:30px;padding-top:20px}.route b{font:700 26px Head;color:#007d80}.route p{font-size:21px}.cover-bottom{border-inline-start:4px solid #e3a329;padding-inline-start:18px;margin:35px 0 20px;font-size:23px}
@media print{body{background:white}.sheet{margin:0}}@media screen and (max-width:800px){.sheet{width:100%;height:auto;min-height:0;margin:0;padding:22px 18px 35px;border-bottom:2px solid #d9e3e7}.footer{position:static;margin-top:30px}.eq{overflow-x:auto}.cover h1{font-size:40px}h1{font-size:28px}}
'''
def head(title,style):return '<!doctype html><html lang="ar-SA" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>'+style+'</style><body>'
render=[]
for i,p in enumerate(pages,1):
    body='<div class="mast"><span class="brand">رياض ١١١</span><span>'+p['group']+'</span></div>'
    if p['active'] is not None:body+=progress(p['active'])
    body+='<h1>'+p['title']+'</h1>'+p['body']
    render.append(f'<section class="sheet {p["kind"]}" id="p{i}" data-page="{i}"><div class="content">{body}</div><footer class="footer"><span>الرابع ضمن التحديد · التجزئة 5.1</span><span dir="ltr">{i} / {len(pages)}</span></footer></section>')
(OUT/'study.html').write_text(head('رياض ١١١ — من السؤال إلى الحل',css)+''.join(render)+'</body></html>')
(ROOT/'pages.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2))
(ROOT/'maths.json').write_text(json.dumps(maths,ensure_ascii=False))
(ROOT/'style.css').write_text(css)

# Full solutions use the same authored mathematics; remove duplicated first steps.
blocks=[]
blocks.append('<section class="sol-cover"><div class="scope">الرابع ضمن التحديد · التجزئة 5.1</div><h1>الحلول التفصيلية</h1>'+P('٢٦ حلًا للتدريب الموجّه والمستقل، وإجابات الاسترجاع، وتفسير القواعد.')+rule('افتح التلميح أولًا. إذا لم يكفِ، اقرأ أول خطوة فقط؛ بعدها أكمل وحدك قبل كشف بقية الحل.')+P('المعرّف المكتوب أعلى السؤال يطابق معرّف الحل. العلامات والنتائج مبنية على أسئلتك المختارة، لا على توقع مضمون للاختبار.')+'</section>')
for q in DATA:
    qid=q['id']
    if q['stage']=='worked':continue
    steps=S[qid]['steps']
    first='<h2>'+qid+'</h2>'+question(qid)+P('<b>التلميح:</b> '+S[qid]['hint'])+row(1,'ابدأ هنا: '+steps[0][0],'',steps[0][1])
    rest=''.join(row(i,text,'',tex) for i,(text,tex) in enumerate(steps[1:-1],2))
    rest+=P(steps[-1][0])+answer(steps[-1][1])+domain(qid)
    blocks.append('<article class="solution" id="s-'+qid+'"><div class="solution-start">'+first+'</div>'+rest+'</article>')
# Carry detailed foundations/proofs into the companion instead of deleting them.
old=json.loads((ROOT/'legacy_explanations.json').read_text()) if (ROOT/'legacy_explanations.json').exists() else json.load(open('/workspace/riyad111_workbook45/pages.json'))
import re,markdown
def mdmath(text):
    def render(m):return '\n\n'+E(m.group(1).strip())+'\n\n'
    return markdown.markdown(re.sub(r'\$\$(.*?)\$\$',render,text,flags=re.S),extensions=['tables'])
recall=H('أ. الجذر الصغير')+E(r'u=\sqrt x,\quad x=u^2,\quad dx=2u\,du')+P('بعد الاختصار يصبح الجذر وحده في المقام، ومعامل التكامل اثنان.')+H('ب. التربيعي مع ثلاثة البسط')+E(r'\frac62=3,\qquad 3\ln\left|x+3+\sqrt{x^2+6x-16}\right|+C')+H('ج. لماذا بعد التحويل؟')+P('تعويض الأُسّي يضيف عامل الداخل في مقام التفاضل، بينما تفاضل اللوغاريتم يستهلك عامل المتغير الموجود أصلًا. لذلك الشكل المحوّل هو الحاسم.')
blocks.append('<section class="back-section" id="recall"><h2>إجابات التمييز والاسترجاع</h2>'+recall+
    H('١. قانون السلسلة والطبقات')+E(r'[F(u)]\prime=F\prime(u)u\prime')+P('في الجيب الزائدي المكعب مع المقلوب ثلاث طبقات: القوة، والدالة الزائدية، والمقلوب.')+
    H('٢. الإشارات والمقام')+P('المباشرات السالبة: ظل التمام، والقاطع، وقاطع التمام. في المعكوسين الآخرين: معكوس القاطع له عامل الداخل، ومعكوس قاطع التمام له قيمته المطلقة؛ كلاهما سالب.')+
    H('٣. الجذور')+P('اكتب التفاضل، ثم اختر بعد تحويل التكامل كله. الصيغ وشروطها في المذكرة؛ لا تختَر من العامل الأصلي وحده.')+
    H('٤. قالب اللوغاريتم')+E(r'm=n+1\ne0,\qquad\frac{x^m}{m}\left(\ln|ax|-\frac1m\right)+C')+
    H('٥. اختيار التجزئة')+P('العامل الخطي يصبح ثابتًا بعد التفاضل. العكسية وحدها عاملها واحد وتكامله المتغير؛ ومع عامل المتغير يصبح تكامله نصف المربع.')+
    H('٦. التكامل المحدد')+E(r'\int_a^b f(x)dx=F(b)-F(a)')+P('الأعلى ناقص الأدنى، ولا يبقى ثابت التكامل في النتيجة.')+'</section>')
for index in [4,5,16,18,24,25]:
    p=old[index-1]
    blocks.append('<section class="back-section"><h2>'+p['title']+'</h2>'+mdmath(p['body'])+'</section>')
table='<section class="back-section" id="sources"><h2>سجل الأسئلة والمصادر</h2>'+P('٣٣ سؤالًا مختلفًا من الميدتيرم الثاني في ستة نماذج من ١٤٤٥–١٤٤٧. الرابع ضمن التحديد السابق ودرس 5.1 فقط. التكاملات المباشرة الزائدية المستبعدة وبقية الخامس والنهايات خارج هذا الملف.')+'<table><tr><th>السؤال</th><th>موضعه</th><th>المصدر</th></tr>'
stages={'worked':'مثال محلول','guided':'تدريب موجّه','independent':'حل مستقل'}
for q in DATA:table+='<tr><td dir="ltr">'+q['id']+'</td><td>'+stages[q['stage']]+'</td><td><a href="'+q['source']+'">صفحة الاختبار</a></td></tr>'
table+='</table>'+P('الاختصارات صيغ صحيحة على شروطها؛ عبارات الحفظ وسائل لاسترجاعها. فحص صحة النتائج لا يقيس سهولة حفظها قبل تجربتك. تمت المحافظة على التفصيل الأساسي في الملحق لتعود إليه عند الحاجة.')+'</section>'
blocks.append(table)
solcss=css+'''
@page{size:A4;margin:13mm 18mm 16mm;@bottom-center{content:counter(page);font-family:Head;font-size:10px;color:#607c8b}@top-right{content:"رياض ١١١ · الحلول التفصيلية";font-family:Head;font-size:10px;color:#607c8b}}
body{background:white;direction:ltr;font-size:20px;line-height:1.6}#solutions{direction:rtl}.solution,.back-section{direction:rtl;margin-bottom:24px}.solution-start{break-inside:avoid}.sol-cover{direction:rtl;padding-top:25mm;break-after:page}.sol-cover h1{font-size:40px}.solution h2,.back-section h2{font:700 23px/1.5 Head;color:#164f74;margin:22px 0 12px;break-after:avoid}.solution h2{direction:ltr;text-align:left}.solution .row h3{font-size:15px}.solution .row{padding:5px 0}.solution .eq{margin:8px 0}.solution .answer{break-inside:avoid}.solution-start .question-head{break-inside:avoid}.back-section:first-of-type{break-before:page}table{border-collapse:collapse;width:100%;font-size:15px}th,td{padding:6px 8px;border-bottom:1px solid #d9e3e7;text-align:right}tr{break-inside:avoid}th{background:#eef6f7}.back-section h2{string-set:section content(text)}.pagedjs_pages{background:#e6edf0}.pagedjs_page{background:white;margin:12px auto}.eq{break-inside:avoid}
@media print{.pagedjs_pages{background:white}.pagedjs_page{margin:0}}
'''
(OUT/'solutions_source.html').write_text(head('رياض ١١١ — الحلول والتفسير',solcss).replace('dir="rtl"','dir="ltr"',1)+'<main id="solutions">'+''.join(blocks)+'</main></body></html>')
(ROOT/'metadata.json').write_text(json.dumps({'questions':DATA,'main_pages':len(pages),'section_starts':starts},ensure_ascii=False,indent=2))
print(json.dumps({'main_pages':len(pages),'questions':len(Q),'authored_solutions':26,'math_blocks':len(maths)},ensure_ascii=False))
