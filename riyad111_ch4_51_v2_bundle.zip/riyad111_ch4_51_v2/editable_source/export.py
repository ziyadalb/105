from pathlib import Path
import json
from playwright.sync_api import sync_playwright
import pymupdf,pikepdf
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parent;OUT=Path('/workspace/output/riyad111_ch4_51_v2')
QA=ROOT/'qa';QA.mkdir(exist_ok=True)
TOOLS=Path('/workspace/riyad111_workbook45/layout-tools/node_modules')
checks={}
with sync_playwright() as driver:
    browser=driver.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    for name,source in [('study','study.html'),('solutions','solutions_source.html')]:
        page=browser.new_page(viewport={'width':1100,'height':1400})
        raw=(OUT/source).read_text();page.set_content(raw,wait_until='load');page.evaluate('document.fonts.ready')
        if name=='study':
            page.emulate_media(media='print')
            result=page.evaluate('''()=>({pages:[...document.querySelectorAll('.sheet')].map(s=>({page:+s.dataset.page,title:s.querySelector('h1').textContent,overflow:Math.max(0,s.querySelector('.content').getBoundingClientRect().bottom-s.querySelector('.footer').getBoundingClientRect().top+12)})),wide:[...document.querySelectorAll('.eq')].filter(e=>e.scrollWidth>e.clientWidth+2).map(e=>({page:+e.closest('.sheet').dataset.page,math:e.textContent,width:e.scrollWidth,available:e.clientWidth})),maths:document.querySelectorAll('math').length})''')
            (QA/'main_layout.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
            bad=[s for s in result['pages'] if s['overflow']]
            print('Main overflow:',json.dumps(bad,ensure_ascii=False),flush=True)
            print('Main wide:',json.dumps(result['wide'],ensure_ascii=False),flush=True)
            if bad or result['wide']:browser.close();raise SystemExit(2)
            expected=len(result['pages'])
        else:
            page.add_script_tag(content='window.PagedConfig={auto:false};')
            page.add_script_tag(path=str(TOOLS/'pagedjs/dist/paged.polyfill.js'))
            page.evaluate('''async()=>{await new Paged.Previewer().preview();await document.fonts.ready;}''')
            result=page.evaluate('''()=>({page_count:document.querySelectorAll('.pagedjs_page').length,maths:document.querySelectorAll('.pagedjs_page math').length,wide:[...document.querySelectorAll('.pagedjs_page .eq')].filter(e=>e.scrollWidth>e.clientWidth+2).map(e=>({page:e.closest('.pagedjs_page').dataset.pageNumber,math:e.textContent,width:e.scrollWidth,available:e.clientWidth})),oversized:[...document.querySelectorAll('.pagedjs_page .row,.pagedjs_page .solution-start')].filter(e=>e.getBoundingClientRect().height>e.closest('.pagedjs_page').querySelector('.pagedjs_area').getBoundingClientRect().height).length})''')
            print('Solutions layout:',json.dumps(result,ensure_ascii=False),flush=True)
            expected=result['page_count']
            if result['wide'] or result['oversized']:browser.close();raise SystemExit(2)
        page.pdf(path=str(OUT/(name+'.pdf')),prefer_css_page_size=True,print_background=True,scale=1,tagged=True,outline=True)
        if name=='study':
            page.emulate_media(media='screen');page.set_viewport_size({'width':390,'height':844})
            result['mobile_document_overflow']=page.evaluate('document.documentElement.scrollWidth>innerWidth+2')
        else:
            script='<script>window.PagedConfig={auto:false};</script><script>'+(TOOLS/'pagedjs/dist/paged.polyfill.js').read_text()+'</script><script>window.addEventListener("load",async()=>{await document.fonts.ready;await new Paged.Previewer().preview();});</script>'
            (OUT/'solutions.html').write_text(raw.replace('</body>',script+'</body>'))
        page.close()
        doc=pymupdf.open(OUT/(name+'.pdf'));assert len(doc)==expected,(name,len(doc),expected)
        texts=[p.get_text() for p in doc];assert all(t.strip() for t in texts)
        (QA/(name+'_text.txt')).write_text('\n\f\n'.join(texts))
        for i,p in enumerate(doc):p.get_pixmap(matrix=pymupdf.Matrix(.8,.8),alpha=False).save(QA/f'{name}-{i+1:02}.png')
        for start in range(0,len(doc),12):
            canvas=Image.new('RGB',(1072,1200),'#e6edf0');draw=ImageDraw.Draw(canvas)
            for j in range(start,min(start+12,len(doc))):
                im=Image.open(QA/f'{name}-{j+1:02}.png');im.thumbnail((252,365));col=(j-start)%4;row=(j-start)//4
                canvas.paste(im,(268*col+8,400*row+22));draw.text((268*col+10,400*row+5),str(j+1),fill='black')
            canvas.save(QA/f'{name}-contact-{start//12+1}.png')
        result['pdf_pages']=len(doc);result['arabic_searchable']=all(w in ''.join(texts) for w in ['التكامل','الداخل'])
        doc.close()
        with pikepdf.open(OUT/(name+'.pdf')) as pdf:pdf.save(OUT/(name+'.opt.pdf'),compress_streams=True,object_stream_mode=pikepdf.ObjectStreamMode.generate)
        (OUT/(name+'.opt.pdf')).replace(OUT/(name+'.pdf'))
        checks[name]=result
    browser.close()
(QA/'layout_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print(json.dumps({n:{'pdf_pages':r['pdf_pages'],'arabic_searchable':r['arabic_searchable']} for n,r in checks.items()},ensure_ascii=False))
